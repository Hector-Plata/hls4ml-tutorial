//Numpy array shape [5]
//Min -0.197568833828
//Max 0.109494589269
//Number of zeros 0

#ifndef B11_H_
#define B11_H_

#ifndef __SYNTHESIS__
model_default_t b11[5];
#else
model_default_t b11[5] = {0.0168554001, 0.0116773248, 0.0301730260, -0.1975688338, 0.1094945893};
#endif

#endif
