//Numpy array shape [5]
//Min -0.086764536798
//Max 0.044536925852
//Number of zeros 0

#ifndef B11_H_
#define B11_H_

#ifndef __SYNTHESIS__
model_default_t b11[5];
#else
model_default_t b11[5] = {-0.0094692213, 0.0445369259, -0.0148535892, 0.0367105864, -0.0867645368};
#endif

#endif
