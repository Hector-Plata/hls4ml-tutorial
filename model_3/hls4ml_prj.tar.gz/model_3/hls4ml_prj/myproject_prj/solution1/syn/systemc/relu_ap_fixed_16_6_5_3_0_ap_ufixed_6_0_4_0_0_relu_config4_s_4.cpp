#include "relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_tmp_340_fu_7640_p3() {
    tmp_340_fu_7640_p3 = add_ln415_80_fu_7634_p2.read().range(5, 5);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_tmp_341_fu_7722_p3() {
    tmp_341_fu_7722_p3 = data_55_V_read.read().range(4, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_tmp_342_fu_7740_p3() {
    tmp_342_fu_7740_p3 = data_55_V_read.read().range(9, 9);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_tmp_343_fu_7754_p3() {
    tmp_343_fu_7754_p3 = data_55_V_read.read().range(3, 3);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_tmp_344_fu_7778_p3() {
    tmp_344_fu_7778_p3 = add_ln415_81_fu_7772_p2.read().range(5, 5);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_tmp_345_fu_7860_p3() {
    tmp_345_fu_7860_p3 = data_56_V_read.read().range(4, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_tmp_346_fu_7878_p3() {
    tmp_346_fu_7878_p3 = data_56_V_read.read().range(9, 9);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_tmp_347_fu_7892_p3() {
    tmp_347_fu_7892_p3 = data_56_V_read.read().range(3, 3);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_tmp_348_fu_7916_p3() {
    tmp_348_fu_7916_p3 = add_ln415_82_fu_7910_p2.read().range(5, 5);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_tmp_349_fu_7998_p3() {
    tmp_349_fu_7998_p3 = data_57_V_read.read().range(4, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_tmp_350_fu_8016_p3() {
    tmp_350_fu_8016_p3 = data_57_V_read.read().range(9, 9);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_tmp_351_fu_8030_p3() {
    tmp_351_fu_8030_p3 = data_57_V_read.read().range(3, 3);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_tmp_352_fu_8054_p3() {
    tmp_352_fu_8054_p3 = add_ln415_83_fu_8048_p2.read().range(5, 5);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_tmp_353_fu_8136_p3() {
    tmp_353_fu_8136_p3 = data_58_V_read.read().range(4, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_tmp_354_fu_8154_p3() {
    tmp_354_fu_8154_p3 = data_58_V_read.read().range(9, 9);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_tmp_355_fu_8168_p3() {
    tmp_355_fu_8168_p3 = data_58_V_read.read().range(3, 3);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_tmp_356_fu_8192_p3() {
    tmp_356_fu_8192_p3 = add_ln415_84_fu_8186_p2.read().range(5, 5);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_tmp_357_fu_8274_p3() {
    tmp_357_fu_8274_p3 = data_59_V_read.read().range(4, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_tmp_358_fu_8292_p3() {
    tmp_358_fu_8292_p3 = data_59_V_read.read().range(9, 9);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_tmp_359_fu_8306_p3() {
    tmp_359_fu_8306_p3 = data_59_V_read.read().range(3, 3);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_tmp_360_fu_8330_p3() {
    tmp_360_fu_8330_p3 = add_ln415_85_fu_8324_p2.read().range(5, 5);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_tmp_361_fu_8412_p3() {
    tmp_361_fu_8412_p3 = data_60_V_read.read().range(4, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_tmp_362_fu_8430_p3() {
    tmp_362_fu_8430_p3 = data_60_V_read.read().range(9, 9);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_tmp_363_fu_8444_p3() {
    tmp_363_fu_8444_p3 = data_60_V_read.read().range(3, 3);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_tmp_364_fu_8468_p3() {
    tmp_364_fu_8468_p3 = add_ln415_86_fu_8462_p2.read().range(5, 5);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_tmp_365_fu_8550_p3() {
    tmp_365_fu_8550_p3 = data_61_V_read.read().range(4, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_tmp_366_fu_8568_p3() {
    tmp_366_fu_8568_p3 = data_61_V_read.read().range(9, 9);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_tmp_367_fu_8582_p3() {
    tmp_367_fu_8582_p3 = data_61_V_read.read().range(3, 3);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_tmp_368_fu_8606_p3() {
    tmp_368_fu_8606_p3 = add_ln415_87_fu_8600_p2.read().range(5, 5);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_tmp_369_fu_8688_p3() {
    tmp_369_fu_8688_p3 = data_62_V_read.read().range(4, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_tmp_370_fu_8706_p3() {
    tmp_370_fu_8706_p3 = data_62_V_read.read().range(9, 9);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_tmp_371_fu_8720_p3() {
    tmp_371_fu_8720_p3 = data_62_V_read.read().range(3, 3);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_tmp_372_fu_8744_p3() {
    tmp_372_fu_8744_p3 = add_ln415_88_fu_8738_p2.read().range(5, 5);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_tmp_373_fu_8826_p3() {
    tmp_373_fu_8826_p3 = data_63_V_read.read().range(4, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_tmp_374_fu_8844_p3() {
    tmp_374_fu_8844_p3 = data_63_V_read.read().range(9, 9);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_tmp_375_fu_8858_p3() {
    tmp_375_fu_8858_p3 = data_63_V_read.read().range(3, 3);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_tmp_376_fu_8882_p3() {
    tmp_376_fu_8882_p3 = add_ln415_89_fu_8876_p2.read().range(5, 5);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_tmp_fu_546_p3() {
    tmp_fu_546_p3 = data_0_V_read.read().range(4, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_29_fu_812_p4() {
    trunc_ln708_29_fu_812_p4 = data_2_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_30_fu_950_p4() {
    trunc_ln708_30_fu_950_p4 = data_3_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_31_fu_1088_p4() {
    trunc_ln708_31_fu_1088_p4 = data_4_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_32_fu_1226_p4() {
    trunc_ln708_32_fu_1226_p4 = data_5_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_33_fu_1364_p4() {
    trunc_ln708_33_fu_1364_p4 = data_6_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_34_fu_1502_p4() {
    trunc_ln708_34_fu_1502_p4 = data_7_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_35_fu_1640_p4() {
    trunc_ln708_35_fu_1640_p4 = data_8_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_36_fu_1778_p4() {
    trunc_ln708_36_fu_1778_p4 = data_9_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_37_fu_1916_p4() {
    trunc_ln708_37_fu_1916_p4 = data_10_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_38_fu_2054_p4() {
    trunc_ln708_38_fu_2054_p4 = data_11_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_39_fu_2192_p4() {
    trunc_ln708_39_fu_2192_p4 = data_12_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_40_fu_2330_p4() {
    trunc_ln708_40_fu_2330_p4 = data_14_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_41_fu_2468_p4() {
    trunc_ln708_41_fu_2468_p4 = data_15_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_42_fu_2606_p4() {
    trunc_ln708_42_fu_2606_p4 = data_17_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_43_fu_2744_p4() {
    trunc_ln708_43_fu_2744_p4 = data_18_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_44_fu_2882_p4() {
    trunc_ln708_44_fu_2882_p4 = data_19_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_45_fu_3020_p4() {
    trunc_ln708_45_fu_3020_p4 = data_20_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_46_fu_3158_p4() {
    trunc_ln708_46_fu_3158_p4 = data_21_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_47_fu_3296_p4() {
    trunc_ln708_47_fu_3296_p4 = data_22_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_48_fu_3434_p4() {
    trunc_ln708_48_fu_3434_p4 = data_23_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_49_fu_3572_p4() {
    trunc_ln708_49_fu_3572_p4 = data_24_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_50_fu_3710_p4() {
    trunc_ln708_50_fu_3710_p4 = data_25_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_51_fu_3848_p4() {
    trunc_ln708_51_fu_3848_p4 = data_26_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_52_fu_3986_p4() {
    trunc_ln708_52_fu_3986_p4 = data_27_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_53_fu_4124_p4() {
    trunc_ln708_53_fu_4124_p4 = data_28_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_54_fu_4262_p4() {
    trunc_ln708_54_fu_4262_p4 = data_29_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_55_fu_4400_p4() {
    trunc_ln708_55_fu_4400_p4 = data_30_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_56_fu_4538_p4() {
    trunc_ln708_56_fu_4538_p4 = data_31_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_57_fu_4676_p4() {
    trunc_ln708_57_fu_4676_p4 = data_32_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_58_fu_4814_p4() {
    trunc_ln708_58_fu_4814_p4 = data_34_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_59_fu_4952_p4() {
    trunc_ln708_59_fu_4952_p4 = data_35_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_60_fu_5090_p4() {
    trunc_ln708_60_fu_5090_p4 = data_36_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_61_fu_5228_p4() {
    trunc_ln708_61_fu_5228_p4 = data_37_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_62_fu_5366_p4() {
    trunc_ln708_62_fu_5366_p4 = data_38_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_63_fu_5504_p4() {
    trunc_ln708_63_fu_5504_p4 = data_39_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_64_fu_5642_p4() {
    trunc_ln708_64_fu_5642_p4 = data_40_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_65_fu_5780_p4() {
    trunc_ln708_65_fu_5780_p4 = data_41_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_66_fu_5918_p4() {
    trunc_ln708_66_fu_5918_p4 = data_42_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_67_fu_6056_p4() {
    trunc_ln708_67_fu_6056_p4 = data_43_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_68_fu_6194_p4() {
    trunc_ln708_68_fu_6194_p4 = data_44_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_69_fu_6332_p4() {
    trunc_ln708_69_fu_6332_p4 = data_45_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_70_fu_6470_p4() {
    trunc_ln708_70_fu_6470_p4 = data_46_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_71_fu_6608_p4() {
    trunc_ln708_71_fu_6608_p4 = data_47_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_72_fu_6746_p4() {
    trunc_ln708_72_fu_6746_p4 = data_48_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_73_fu_6884_p4() {
    trunc_ln708_73_fu_6884_p4 = data_49_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_74_fu_7022_p4() {
    trunc_ln708_74_fu_7022_p4 = data_50_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_75_fu_7160_p4() {
    trunc_ln708_75_fu_7160_p4 = data_51_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_76_fu_7298_p4() {
    trunc_ln708_76_fu_7298_p4 = data_52_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_77_fu_7436_p4() {
    trunc_ln708_77_fu_7436_p4 = data_53_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_78_fu_7574_p4() {
    trunc_ln708_78_fu_7574_p4 = data_54_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_79_fu_7712_p4() {
    trunc_ln708_79_fu_7712_p4 = data_55_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_80_fu_7850_p4() {
    trunc_ln708_80_fu_7850_p4 = data_56_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_81_fu_7988_p4() {
    trunc_ln708_81_fu_7988_p4 = data_57_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_82_fu_8126_p4() {
    trunc_ln708_82_fu_8126_p4 = data_58_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_83_fu_8264_p4() {
    trunc_ln708_83_fu_8264_p4 = data_59_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_84_fu_8402_p4() {
    trunc_ln708_84_fu_8402_p4 = data_60_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_85_fu_8540_p4() {
    trunc_ln708_85_fu_8540_p4 = data_61_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_86_fu_8678_p4() {
    trunc_ln708_86_fu_8678_p4 = data_62_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_87_fu_8816_p4() {
    trunc_ln708_87_fu_8816_p4 = data_63_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln708_s_fu_674_p4() {
    trunc_ln708_s_fu_674_p4 = data_1_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_30_fu_692_p1() {
    trunc_ln718_30_fu_692_p1 = data_1_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_31_fu_830_p1() {
    trunc_ln718_31_fu_830_p1 = data_2_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_32_fu_968_p1() {
    trunc_ln718_32_fu_968_p1 = data_3_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_33_fu_1106_p1() {
    trunc_ln718_33_fu_1106_p1 = data_4_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_34_fu_1244_p1() {
    trunc_ln718_34_fu_1244_p1 = data_5_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_35_fu_1382_p1() {
    trunc_ln718_35_fu_1382_p1 = data_6_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_36_fu_1520_p1() {
    trunc_ln718_36_fu_1520_p1 = data_7_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_37_fu_1658_p1() {
    trunc_ln718_37_fu_1658_p1 = data_8_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_38_fu_1796_p1() {
    trunc_ln718_38_fu_1796_p1 = data_9_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_39_fu_1934_p1() {
    trunc_ln718_39_fu_1934_p1 = data_10_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_40_fu_2072_p1() {
    trunc_ln718_40_fu_2072_p1 = data_11_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_41_fu_2210_p1() {
    trunc_ln718_41_fu_2210_p1 = data_12_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_42_fu_2348_p1() {
    trunc_ln718_42_fu_2348_p1 = data_14_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_43_fu_2486_p1() {
    trunc_ln718_43_fu_2486_p1 = data_15_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_44_fu_2624_p1() {
    trunc_ln718_44_fu_2624_p1 = data_17_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_45_fu_2762_p1() {
    trunc_ln718_45_fu_2762_p1 = data_18_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_46_fu_2900_p1() {
    trunc_ln718_46_fu_2900_p1 = data_19_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_47_fu_3038_p1() {
    trunc_ln718_47_fu_3038_p1 = data_20_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_48_fu_3176_p1() {
    trunc_ln718_48_fu_3176_p1 = data_21_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_49_fu_3314_p1() {
    trunc_ln718_49_fu_3314_p1 = data_22_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_50_fu_3452_p1() {
    trunc_ln718_50_fu_3452_p1 = data_23_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_51_fu_3590_p1() {
    trunc_ln718_51_fu_3590_p1 = data_24_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_52_fu_3728_p1() {
    trunc_ln718_52_fu_3728_p1 = data_25_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_53_fu_3866_p1() {
    trunc_ln718_53_fu_3866_p1 = data_26_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_54_fu_4004_p1() {
    trunc_ln718_54_fu_4004_p1 = data_27_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_55_fu_4142_p1() {
    trunc_ln718_55_fu_4142_p1 = data_28_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_56_fu_4280_p1() {
    trunc_ln718_56_fu_4280_p1 = data_29_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_57_fu_4418_p1() {
    trunc_ln718_57_fu_4418_p1 = data_30_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_58_fu_4556_p1() {
    trunc_ln718_58_fu_4556_p1 = data_31_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_59_fu_4694_p1() {
    trunc_ln718_59_fu_4694_p1 = data_32_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_60_fu_4832_p1() {
    trunc_ln718_60_fu_4832_p1 = data_34_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_61_fu_4970_p1() {
    trunc_ln718_61_fu_4970_p1 = data_35_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_62_fu_5108_p1() {
    trunc_ln718_62_fu_5108_p1 = data_36_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_63_fu_5246_p1() {
    trunc_ln718_63_fu_5246_p1 = data_37_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_64_fu_5384_p1() {
    trunc_ln718_64_fu_5384_p1 = data_38_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_65_fu_5522_p1() {
    trunc_ln718_65_fu_5522_p1 = data_39_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_66_fu_5660_p1() {
    trunc_ln718_66_fu_5660_p1 = data_40_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_67_fu_5798_p1() {
    trunc_ln718_67_fu_5798_p1 = data_41_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_68_fu_5936_p1() {
    trunc_ln718_68_fu_5936_p1 = data_42_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_69_fu_6074_p1() {
    trunc_ln718_69_fu_6074_p1 = data_43_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_70_fu_6212_p1() {
    trunc_ln718_70_fu_6212_p1 = data_44_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_71_fu_6350_p1() {
    trunc_ln718_71_fu_6350_p1 = data_45_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_72_fu_6488_p1() {
    trunc_ln718_72_fu_6488_p1 = data_46_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_73_fu_6626_p1() {
    trunc_ln718_73_fu_6626_p1 = data_47_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_74_fu_6764_p1() {
    trunc_ln718_74_fu_6764_p1 = data_48_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_75_fu_6902_p1() {
    trunc_ln718_75_fu_6902_p1 = data_49_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_76_fu_7040_p1() {
    trunc_ln718_76_fu_7040_p1 = data_50_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_77_fu_7178_p1() {
    trunc_ln718_77_fu_7178_p1 = data_51_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_78_fu_7316_p1() {
    trunc_ln718_78_fu_7316_p1 = data_52_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_79_fu_7454_p1() {
    trunc_ln718_79_fu_7454_p1 = data_53_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_80_fu_7592_p1() {
    trunc_ln718_80_fu_7592_p1 = data_54_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_81_fu_7730_p1() {
    trunc_ln718_81_fu_7730_p1 = data_55_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_82_fu_7868_p1() {
    trunc_ln718_82_fu_7868_p1 = data_56_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_83_fu_8006_p1() {
    trunc_ln718_83_fu_8006_p1 = data_57_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_84_fu_8144_p1() {
    trunc_ln718_84_fu_8144_p1 = data_58_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_85_fu_8282_p1() {
    trunc_ln718_85_fu_8282_p1 = data_59_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_86_fu_8420_p1() {
    trunc_ln718_86_fu_8420_p1 = data_60_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_87_fu_8558_p1() {
    trunc_ln718_87_fu_8558_p1 = data_61_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_88_fu_8696_p1() {
    trunc_ln718_88_fu_8696_p1 = data_62_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_89_fu_8834_p1() {
    trunc_ln718_89_fu_8834_p1 = data_63_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln718_fu_554_p1() {
    trunc_ln718_fu_554_p1 = data_0_V_read.read().range(3-1, 0);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_trunc_ln_fu_536_p4() {
    trunc_ln_fu_536_p4 = data_0_V_read.read().range(9, 4);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_30_fu_748_p2() {
    xor_ln416_30_fu_748_p2 = (tmp_140_fu_740_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_31_fu_886_p2() {
    xor_ln416_31_fu_886_p2 = (tmp_144_fu_878_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_32_fu_1024_p2() {
    xor_ln416_32_fu_1024_p2 = (tmp_148_fu_1016_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_33_fu_1162_p2() {
    xor_ln416_33_fu_1162_p2 = (tmp_152_fu_1154_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_34_fu_1300_p2() {
    xor_ln416_34_fu_1300_p2 = (tmp_156_fu_1292_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_35_fu_1438_p2() {
    xor_ln416_35_fu_1438_p2 = (tmp_160_fu_1430_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_36_fu_1576_p2() {
    xor_ln416_36_fu_1576_p2 = (tmp_164_fu_1568_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_37_fu_1714_p2() {
    xor_ln416_37_fu_1714_p2 = (tmp_168_fu_1706_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_38_fu_1852_p2() {
    xor_ln416_38_fu_1852_p2 = (tmp_172_fu_1844_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_39_fu_1990_p2() {
    xor_ln416_39_fu_1990_p2 = (tmp_176_fu_1982_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_40_fu_2128_p2() {
    xor_ln416_40_fu_2128_p2 = (tmp_180_fu_2120_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_41_fu_2266_p2() {
    xor_ln416_41_fu_2266_p2 = (tmp_184_fu_2258_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_42_fu_2404_p2() {
    xor_ln416_42_fu_2404_p2 = (tmp_188_fu_2396_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_43_fu_2542_p2() {
    xor_ln416_43_fu_2542_p2 = (tmp_192_fu_2534_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_44_fu_2680_p2() {
    xor_ln416_44_fu_2680_p2 = (tmp_196_fu_2672_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_45_fu_2818_p2() {
    xor_ln416_45_fu_2818_p2 = (tmp_200_fu_2810_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_46_fu_2956_p2() {
    xor_ln416_46_fu_2956_p2 = (tmp_204_fu_2948_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_47_fu_3094_p2() {
    xor_ln416_47_fu_3094_p2 = (tmp_208_fu_3086_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_48_fu_3232_p2() {
    xor_ln416_48_fu_3232_p2 = (tmp_212_fu_3224_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_49_fu_3370_p2() {
    xor_ln416_49_fu_3370_p2 = (tmp_216_fu_3362_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_50_fu_3508_p2() {
    xor_ln416_50_fu_3508_p2 = (tmp_220_fu_3500_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_51_fu_3646_p2() {
    xor_ln416_51_fu_3646_p2 = (tmp_224_fu_3638_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_52_fu_3784_p2() {
    xor_ln416_52_fu_3784_p2 = (tmp_228_fu_3776_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_53_fu_3922_p2() {
    xor_ln416_53_fu_3922_p2 = (tmp_232_fu_3914_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_54_fu_4060_p2() {
    xor_ln416_54_fu_4060_p2 = (tmp_236_fu_4052_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_55_fu_4198_p2() {
    xor_ln416_55_fu_4198_p2 = (tmp_240_fu_4190_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_56_fu_4336_p2() {
    xor_ln416_56_fu_4336_p2 = (tmp_244_fu_4328_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_57_fu_4474_p2() {
    xor_ln416_57_fu_4474_p2 = (tmp_248_fu_4466_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_58_fu_4612_p2() {
    xor_ln416_58_fu_4612_p2 = (tmp_252_fu_4604_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_59_fu_4750_p2() {
    xor_ln416_59_fu_4750_p2 = (tmp_256_fu_4742_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_60_fu_4888_p2() {
    xor_ln416_60_fu_4888_p2 = (tmp_260_fu_4880_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_61_fu_5026_p2() {
    xor_ln416_61_fu_5026_p2 = (tmp_264_fu_5018_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_62_fu_5164_p2() {
    xor_ln416_62_fu_5164_p2 = (tmp_268_fu_5156_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_63_fu_5302_p2() {
    xor_ln416_63_fu_5302_p2 = (tmp_272_fu_5294_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_64_fu_5440_p2() {
    xor_ln416_64_fu_5440_p2 = (tmp_276_fu_5432_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_65_fu_5578_p2() {
    xor_ln416_65_fu_5578_p2 = (tmp_280_fu_5570_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_66_fu_5716_p2() {
    xor_ln416_66_fu_5716_p2 = (tmp_284_fu_5708_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_67_fu_5854_p2() {
    xor_ln416_67_fu_5854_p2 = (tmp_288_fu_5846_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_68_fu_5992_p2() {
    xor_ln416_68_fu_5992_p2 = (tmp_292_fu_5984_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_69_fu_6130_p2() {
    xor_ln416_69_fu_6130_p2 = (tmp_296_fu_6122_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_70_fu_6268_p2() {
    xor_ln416_70_fu_6268_p2 = (tmp_300_fu_6260_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_71_fu_6406_p2() {
    xor_ln416_71_fu_6406_p2 = (tmp_304_fu_6398_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_72_fu_6544_p2() {
    xor_ln416_72_fu_6544_p2 = (tmp_308_fu_6536_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_73_fu_6682_p2() {
    xor_ln416_73_fu_6682_p2 = (tmp_312_fu_6674_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_74_fu_6820_p2() {
    xor_ln416_74_fu_6820_p2 = (tmp_316_fu_6812_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_75_fu_6958_p2() {
    xor_ln416_75_fu_6958_p2 = (tmp_320_fu_6950_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_76_fu_7096_p2() {
    xor_ln416_76_fu_7096_p2 = (tmp_324_fu_7088_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_77_fu_7234_p2() {
    xor_ln416_77_fu_7234_p2 = (tmp_328_fu_7226_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_78_fu_7372_p2() {
    xor_ln416_78_fu_7372_p2 = (tmp_332_fu_7364_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_79_fu_7510_p2() {
    xor_ln416_79_fu_7510_p2 = (tmp_336_fu_7502_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_80_fu_7648_p2() {
    xor_ln416_80_fu_7648_p2 = (tmp_340_fu_7640_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_81_fu_7786_p2() {
    xor_ln416_81_fu_7786_p2 = (tmp_344_fu_7778_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_82_fu_7924_p2() {
    xor_ln416_82_fu_7924_p2 = (tmp_348_fu_7916_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_83_fu_8062_p2() {
    xor_ln416_83_fu_8062_p2 = (tmp_352_fu_8054_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_84_fu_8200_p2() {
    xor_ln416_84_fu_8200_p2 = (tmp_356_fu_8192_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_85_fu_8338_p2() {
    xor_ln416_85_fu_8338_p2 = (tmp_360_fu_8330_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_86_fu_8476_p2() {
    xor_ln416_86_fu_8476_p2 = (tmp_364_fu_8468_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_87_fu_8614_p2() {
    xor_ln416_87_fu_8614_p2 = (tmp_368_fu_8606_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_88_fu_8752_p2() {
    xor_ln416_88_fu_8752_p2 = (tmp_372_fu_8744_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_89_fu_8890_p2() {
    xor_ln416_89_fu_8890_p2 = (tmp_376_fu_8882_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_xor_ln416_fu_610_p2() {
    xor_ln416_fu_610_p2 = (tmp_136_fu_602_p3.read() ^ ap_const_lv1_1);
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_30_fu_730_p1() {
    zext_ln415_30_fu_730_p1 = esl_zext<6,1>(and_ln415_1_fu_724_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_31_fu_868_p1() {
    zext_ln415_31_fu_868_p1 = esl_zext<6,1>(and_ln415_2_fu_862_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_32_fu_1006_p1() {
    zext_ln415_32_fu_1006_p1 = esl_zext<6,1>(and_ln415_3_fu_1000_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_33_fu_1144_p1() {
    zext_ln415_33_fu_1144_p1 = esl_zext<6,1>(and_ln415_4_fu_1138_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_34_fu_1282_p1() {
    zext_ln415_34_fu_1282_p1 = esl_zext<6,1>(and_ln415_5_fu_1276_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_35_fu_1420_p1() {
    zext_ln415_35_fu_1420_p1 = esl_zext<6,1>(and_ln415_6_fu_1414_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_36_fu_1558_p1() {
    zext_ln415_36_fu_1558_p1 = esl_zext<6,1>(and_ln415_7_fu_1552_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_37_fu_1696_p1() {
    zext_ln415_37_fu_1696_p1 = esl_zext<6,1>(and_ln415_8_fu_1690_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_38_fu_1834_p1() {
    zext_ln415_38_fu_1834_p1 = esl_zext<6,1>(and_ln415_9_fu_1828_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_39_fu_1972_p1() {
    zext_ln415_39_fu_1972_p1 = esl_zext<6,1>(and_ln415_10_fu_1966_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_40_fu_2110_p1() {
    zext_ln415_40_fu_2110_p1 = esl_zext<6,1>(and_ln415_11_fu_2104_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_41_fu_2248_p1() {
    zext_ln415_41_fu_2248_p1 = esl_zext<6,1>(and_ln415_12_fu_2242_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_42_fu_2386_p1() {
    zext_ln415_42_fu_2386_p1 = esl_zext<6,1>(and_ln415_14_fu_2380_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_43_fu_2524_p1() {
    zext_ln415_43_fu_2524_p1 = esl_zext<6,1>(and_ln415_15_fu_2518_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_44_fu_2662_p1() {
    zext_ln415_44_fu_2662_p1 = esl_zext<6,1>(and_ln415_17_fu_2656_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_45_fu_2800_p1() {
    zext_ln415_45_fu_2800_p1 = esl_zext<6,1>(and_ln415_18_fu_2794_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_46_fu_2938_p1() {
    zext_ln415_46_fu_2938_p1 = esl_zext<6,1>(and_ln415_19_fu_2932_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_47_fu_3076_p1() {
    zext_ln415_47_fu_3076_p1 = esl_zext<6,1>(and_ln415_20_fu_3070_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_48_fu_3214_p1() {
    zext_ln415_48_fu_3214_p1 = esl_zext<6,1>(and_ln415_21_fu_3208_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_49_fu_3352_p1() {
    zext_ln415_49_fu_3352_p1 = esl_zext<6,1>(and_ln415_22_fu_3346_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_50_fu_3490_p1() {
    zext_ln415_50_fu_3490_p1 = esl_zext<6,1>(and_ln415_23_fu_3484_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_51_fu_3628_p1() {
    zext_ln415_51_fu_3628_p1 = esl_zext<6,1>(and_ln415_24_fu_3622_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_52_fu_3766_p1() {
    zext_ln415_52_fu_3766_p1 = esl_zext<6,1>(and_ln415_25_fu_3760_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_53_fu_3904_p1() {
    zext_ln415_53_fu_3904_p1 = esl_zext<6,1>(and_ln415_26_fu_3898_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_54_fu_4042_p1() {
    zext_ln415_54_fu_4042_p1 = esl_zext<6,1>(and_ln415_27_fu_4036_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_55_fu_4180_p1() {
    zext_ln415_55_fu_4180_p1 = esl_zext<6,1>(and_ln415_28_fu_4174_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_56_fu_4318_p1() {
    zext_ln415_56_fu_4318_p1 = esl_zext<6,1>(and_ln415_29_fu_4312_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_57_fu_4456_p1() {
    zext_ln415_57_fu_4456_p1 = esl_zext<6,1>(and_ln415_30_fu_4450_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_58_fu_4594_p1() {
    zext_ln415_58_fu_4594_p1 = esl_zext<6,1>(and_ln415_31_fu_4588_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_59_fu_4732_p1() {
    zext_ln415_59_fu_4732_p1 = esl_zext<6,1>(and_ln415_32_fu_4726_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_60_fu_4870_p1() {
    zext_ln415_60_fu_4870_p1 = esl_zext<6,1>(and_ln415_33_fu_4864_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_61_fu_5008_p1() {
    zext_ln415_61_fu_5008_p1 = esl_zext<6,1>(and_ln415_34_fu_5002_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_62_fu_5146_p1() {
    zext_ln415_62_fu_5146_p1 = esl_zext<6,1>(and_ln415_35_fu_5140_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_63_fu_5284_p1() {
    zext_ln415_63_fu_5284_p1 = esl_zext<6,1>(and_ln415_36_fu_5278_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_64_fu_5422_p1() {
    zext_ln415_64_fu_5422_p1 = esl_zext<6,1>(and_ln415_37_fu_5416_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_65_fu_5560_p1() {
    zext_ln415_65_fu_5560_p1 = esl_zext<6,1>(and_ln415_38_fu_5554_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_66_fu_5698_p1() {
    zext_ln415_66_fu_5698_p1 = esl_zext<6,1>(and_ln415_39_fu_5692_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_67_fu_5836_p1() {
    zext_ln415_67_fu_5836_p1 = esl_zext<6,1>(and_ln415_40_fu_5830_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_68_fu_5974_p1() {
    zext_ln415_68_fu_5974_p1 = esl_zext<6,1>(and_ln415_41_fu_5968_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_69_fu_6112_p1() {
    zext_ln415_69_fu_6112_p1 = esl_zext<6,1>(and_ln415_42_fu_6106_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_70_fu_6250_p1() {
    zext_ln415_70_fu_6250_p1 = esl_zext<6,1>(and_ln415_43_fu_6244_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_71_fu_6388_p1() {
    zext_ln415_71_fu_6388_p1 = esl_zext<6,1>(and_ln415_44_fu_6382_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_72_fu_6526_p1() {
    zext_ln415_72_fu_6526_p1 = esl_zext<6,1>(and_ln415_45_fu_6520_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_73_fu_6664_p1() {
    zext_ln415_73_fu_6664_p1 = esl_zext<6,1>(and_ln415_46_fu_6658_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_74_fu_6802_p1() {
    zext_ln415_74_fu_6802_p1 = esl_zext<6,1>(and_ln415_47_fu_6796_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_75_fu_6940_p1() {
    zext_ln415_75_fu_6940_p1 = esl_zext<6,1>(and_ln415_48_fu_6934_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_76_fu_7078_p1() {
    zext_ln415_76_fu_7078_p1 = esl_zext<6,1>(and_ln415_49_fu_7072_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_77_fu_7216_p1() {
    zext_ln415_77_fu_7216_p1 = esl_zext<6,1>(and_ln415_50_fu_7210_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_78_fu_7354_p1() {
    zext_ln415_78_fu_7354_p1 = esl_zext<6,1>(and_ln415_51_fu_7348_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_79_fu_7492_p1() {
    zext_ln415_79_fu_7492_p1 = esl_zext<6,1>(and_ln415_52_fu_7486_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_80_fu_7630_p1() {
    zext_ln415_80_fu_7630_p1 = esl_zext<6,1>(and_ln415_53_fu_7624_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_81_fu_7768_p1() {
    zext_ln415_81_fu_7768_p1 = esl_zext<6,1>(and_ln415_54_fu_7762_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_82_fu_7906_p1() {
    zext_ln415_82_fu_7906_p1 = esl_zext<6,1>(and_ln415_55_fu_7900_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_83_fu_8044_p1() {
    zext_ln415_83_fu_8044_p1 = esl_zext<6,1>(and_ln415_56_fu_8038_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_84_fu_8182_p1() {
    zext_ln415_84_fu_8182_p1 = esl_zext<6,1>(and_ln415_57_fu_8176_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_85_fu_8320_p1() {
    zext_ln415_85_fu_8320_p1 = esl_zext<6,1>(and_ln415_58_fu_8314_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_86_fu_8458_p1() {
    zext_ln415_86_fu_8458_p1 = esl_zext<6,1>(and_ln415_59_fu_8452_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_87_fu_8596_p1() {
    zext_ln415_87_fu_8596_p1 = esl_zext<6,1>(and_ln415_60_fu_8590_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_88_fu_8734_p1() {
    zext_ln415_88_fu_8734_p1 = esl_zext<6,1>(and_ln415_61_fu_8728_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_89_fu_8872_p1() {
    zext_ln415_89_fu_8872_p1 = esl_zext<6,1>(and_ln415_62_fu_8866_p2.read());
}

void relu_ap_fixed_16_6_5_3_0_ap_ufixed_6_0_4_0_0_relu_config4_s::thread_zext_ln415_fu_592_p1() {
    zext_ln415_fu_592_p1 = esl_zext<6,1>(and_ln415_fu_586_p2.read());
}

}

