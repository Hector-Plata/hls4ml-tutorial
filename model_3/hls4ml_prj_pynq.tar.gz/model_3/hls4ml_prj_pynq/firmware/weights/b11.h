//Numpy array shape [5]
//Min -0.718750000000
//Max 0.968750000000
//Number of zeros 0

#ifndef B11_H_
#define B11_H_

#ifndef __SYNTHESIS__
bias11_t b11[5];
#else
bias11_t b11[5] = {0.03125, 0.96875, -0.71875, -0.25000, -0.40625};
#endif

#endif
