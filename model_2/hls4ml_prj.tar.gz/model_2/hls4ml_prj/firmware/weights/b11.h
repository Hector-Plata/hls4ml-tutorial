//Numpy array shape [5]
//Min -0.312868565321
//Max 0.513709723949
//Number of zeros 0

#ifndef B11_H_
#define B11_H_

#ifndef __SYNTHESIS__
model_default_t b11[5];
#else
model_default_t b11[5] = {-0.1915539503, 0.5137097239, 0.1716889888, -0.3128685653, -0.2678752542};
#endif

#endif
