//Numpy array shape [5]
//Min -0.266587585211
//Max 0.336157619953
//Number of zeros 0

#ifndef B11_H_
#define B11_H_

#ifndef __SYNTHESIS__
model_default_t b11[5];
#else
model_default_t b11[5] = {0.1537631303, -0.2665875852, 0.0545562655, -0.2358200848, 0.3361576200};
#endif

#endif
